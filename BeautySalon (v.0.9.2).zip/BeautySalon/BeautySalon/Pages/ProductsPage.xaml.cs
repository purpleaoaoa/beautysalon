﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;

namespace BeautySalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        // Поля //

        private Button Button;
        private readonly BrushConverter BrushConverter = new BrushConverter();

        public ProductsPage()
        {
            InitializeComponent();

            ProductsPageNavigationButtons.MouseEnter += MouseEnter;
            ProductsPageNavigationButtons.MouseLeave += MouseLeave;
        }

        // Событие нажатия кнопки "назад"
        private void ReturnToMainWindowButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        // Методы //

        // Метод наведения мыши на кнопку с изображением
        private new void MouseEnter(object s, MouseEventArgs e)
        {
            Button = s as Button;

            if (Button != null)
            {
                Button.Foreground = Brushes.Yellow;
            }
        }

        // Метод снятия наведения мыши с кнопки с изображением
        private new void MouseLeave(object s, MouseEventArgs e)
        {
            Button = s as Button;

            if (Button != null)
            {
                Button.Foreground = (Brush)BrushConverter.ConvertFrom("#FFFF4A6D");
            }
        }
    }
}