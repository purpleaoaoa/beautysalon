﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace BeautySalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationPage.xaml
    /// </summary>
    public partial class AuthorizationPage : Page
    {
        // Поля //

        private PasswordBox PasswordPasswordBox;
        private readonly BrushConverter BrushConverter = new BrushConverter();
        private RegistrationPage RegistrationPage = new RegistrationPage();

        public AuthorizationPage()
        {
            InitializeComponent();

            PasswordPasswordBox = new PasswordBox()
            {
                Name = "PasswordPasswordBox",
                Foreground = new SolidColorBrush(Color.FromArgb(80, 0, 0, 0)),
                Width = 270,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(0, 0, 0, 10)
            };

            PasswordPasswordBox.Visibility = Visibility.Hidden;
        }

        private void PasswordTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            //PasswordStackPanel.Children.Insert(PasswordStackPanel.Children.IndexOf(PasswordTextBox), PasswordPasswordBox);
            //PasswordStackPanel.Children.Remove(PasswordTextBox);
        }

        // События //

        // Событе нажатия на чекбокс показа пароля
        private void ShowPasswordCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            //PasswordStackPanel.Children.Insert(PasswordStackPanel.Children.IndexOf(PasswordTextBox), PasswordPasswordBox);
            //PasswordStackPanel.Children.Remove(PasswordTextBox);

            //PasswordPasswordBox.Visibility = Visibility.Visible;
        }

        // Событе отжатия чекбокса показа пароля
        private void ShowPasswordCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        // Событие нажатия кнопки "войти"
        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmailTextBox.Text == "test@test.ru" && PasswordPasswordBox.Password == "test12345")
            {
                MessageBox.Show("Здравствуйте, Тестовов Тестер Тестирович!");
            }

            else
            {
                MessageBox.Show("Данные о пользователе не обнаружены в базе данных!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Событе наведения на кнопку регистрации
        private void RegistrationButton_MouseEnter(object sender, MouseEventArgs e)
        {
            RegistrationButton.Foreground = Brushes.Yellow;
        }

        // Событе убирания наведения с кнопки регистрации
        private void RegistrationButton_MouseLeave(object sender, MouseEventArgs e)
        {
            RegistrationButton.Foreground = (Brush)BrushConverter.ConvertFrom("#FFFF4A6D");
        }

        // Событие нажатия кнопки регистрации
        private void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            //Height = 900;
            //Width = 1500;
            //NavigationService.Navigate(new RegistrationPage());
        }
    }
}