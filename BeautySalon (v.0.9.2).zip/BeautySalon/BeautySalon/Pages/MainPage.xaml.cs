﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;

namespace BeautySalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        // Поля //

        private Button Button;
        private Window AuthorizationWindow;
        private Frame AuthorizationFrame;
        private readonly AuthorizationPage AuthorizationPage = new AuthorizationPage();

        public MainPage()
        {
            InitializeComponent();

            NavigateToTelegramButton.MouseEnter += MouseEnter;
            NavigateToTelegramButton.MouseLeave += MouseLeave;

            NavigateToWhatsAppButton.MouseEnter += MouseEnter;
            NavigateToWhatsAppButton.MouseLeave += MouseLeave;
        }

        // События //

        // Событие нажатия кнопки захода в страницу товаров
        private void EnterGoodsPageButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductsPage());
        }

        // Событие нажатия на кнопку авторизации
        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow = new Window()
            {
                Title = "Авторизация",
                ResizeMode = ResizeMode.NoResize,
                WindowStyle = WindowStyle.ToolWindow,
                ShowInTaskbar = false,
                Topmost = true,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Height = 550,
                Width = 400
            };

            AuthorizationFrame = new Frame()
            {
                NavigationUIVisibility = NavigationUIVisibility.Hidden
            };

            AuthorizationFrame.Navigate(AuthorizationPage);
            AuthorizationWindow.Content = AuthorizationFrame;
            AuthorizationWindow.Show();
        }

        // Событие нажатия кнопки перехода в телеграм
        private void NavigateToTelegramButton_Click(object sender, RoutedEventArgs e)
        {
            string url = "https://t.me/BeautySalon_Administration";
            System.Diagnostics.Process.Start(url);
        }

        // Событие нажатия кнопки перехода в ватсап
        private void NavigateToWhatsAppButton_Click(object sender, RoutedEventArgs e)
        {
            string url = "https://chat.whatsapp.com/LvHHqKldV3X9TKMYJr7cBr";
            System.Diagnostics.Process.Start(url);
        }

        // Методы //

        // Метод наведения мыши на кнопку с изображением
        private new void MouseEnter(object s, MouseEventArgs e)
        {
            Button = s as Button;

            if (Button != null)
            {
                ImageBrush ImageBrush = Button.Background as ImageBrush;

                if (ImageBrush != null)
                {
                    TransformGroup TransformGroup = new TransformGroup();
                    TransformGroup.Children.Add(new ScaleTransform(0.85, 0.85));
                    TransformGroup.Children.Add(new TranslateTransform(0.05, 0.05)); // смещение пикселей для сохранения позиции изображения
                    ImageBrush.RelativeTransform = TransformGroup;
                    Button.RenderTransformOrigin = new Point(0.5, 0.5);
                }
            }
        }

        // Метод снятия наведения мыши с кнопки с изображением
        private new void MouseLeave(object s, MouseEventArgs e)
        {
            Button = s as Button;

            if (Button != null)
            {
                ImageBrush ImageBrush = Button.Background as ImageBrush;

                if (ImageBrush != null)
                {
                    ImageBrush.RelativeTransform = new ScaleTransform(1.0, 1.0);
                }
            }
        }
    }
}